# PRODIGY_WD_01
Created a Responsive Website Landing Page using HTML, CSS, JS. 
It has Interactive navigation menu that changes color or style when scrolled or when hovering over a menu item. The navigation menu have a fixed position and be visible on all pages.
Used HTML to structure the menu, CSS to style it, and JavaScript to add interactivity, such as changing the background color or font color of the menu when it is scrolled or when a menu item is hovered over.
Used scrollreveal library to animate elements as they scroll into view.


https://github.com/Tanmay7586/PRODIGY_WD_01/assets/94454903/e5f92e8c-f1c6-4596-aeb8-f120ee251a78

